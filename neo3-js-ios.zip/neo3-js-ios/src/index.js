
"use strict";

import N3Web3Provider from "./neo3_provider"

window.prov = new N3Web3Provider();
